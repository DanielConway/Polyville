﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class CharacterMovement : MonoBehaviour
{
    #region Variables
    public float movSpeed;
    public float rotSpeed;
    public float jumpPow;

    private float jumpWait = .5f;
    private float jumpTimer;

    public Text txtMainPanel;
    public GameObject mainPanel;

    public float slowFogDeath;

    PlayerHealth playerHealth;

    public GameObject alertPanel;
    public Text txtAlert, txtQuests;

    public Sprite spearImage, potionImage, crownImage, hammerImage, mushroomImage, branchImage;

    InventoryScript database;

    private int reqItemNum;
    private int questNum;

    private bool qstPotion, qstSpear, qstCrown, qstHammer, qstBranch, qstMushroom = false;

    private int KingSpeechNum, QueenSpeechNum, BlacksmithSpeechNum, ElderSpeechNum, WizardSpeechNum, AdventurerSpeechNum, GenericCharacterSpeechNum;

    public GameObject queenCrown, blacksmithHammer;

    public Image fadeScreen;

    public GameObject qstPanel;

    private bool CheckIn = false;

    #endregion

    // Use this for initialization
    void Start()
    {
        playerHealth = GameObject.Find("Scripts").GetComponent<PlayerHealth>();
        database = GameObject.Find("Scripts").GetComponent<InventoryScript>();

        reqItemNum = 100;
        questNum = 0;

        //Test Fade
        //StartCoroutine(FadeOut());
    }

    // Update is called once per frame
    void Update()
    {
        //Movement
        jumpTimer += Time.deltaTime;

        if (Input.GetKey(KeyCode.A))
        {
            transform.Rotate(Vector3.back * rotSpeed * Time.deltaTime);
        }
        if (Input.GetKey(KeyCode.D))
        {
            transform.Rotate(-Vector3.back * rotSpeed * Time.deltaTime);
        }
        if (Input.GetKey(KeyCode.W))
        {
            transform.Translate(-Vector3.up * movSpeed * Time.deltaTime);
        }
        if (Input.GetKey(KeyCode.S))
        {
            transform.Translate(Vector3.up * movSpeed * Time.deltaTime);
        }

        //Jumping
        /*
        if (Input.GetKey(KeyCode.Space) && jumpWait < jumpTimer)
        {
            jumpTimer = 0;
            transform.Translate(Vector3.forward * jumpPow * Time.deltaTime);
        }
        */
    }

    void OnTriggerStay(Collider col)
    {
        if (col.tag == "Fog")
        {
            playerHealth.playerHP -= Mathf.CeilToInt(playerHealth.playerHP * Time.deltaTime / slowFogDeath);
        }
        

        if (col.tag == "NPC")
        {
            #region King
            if (col.name == "King")
            {
                txtAlert.text = ("Press Q to continue...");

                if (questNum >= 6 && CheckIn == false)
                {
                    mainPanel.SetActive(true);
                    alertPanel.SetActive(true);
                    CheckIn = true;
                }

                if(questNum < 6)
                {
                    mainPanel.SetActive(true);
                    alertPanel.SetActive(true);
                }

                if (KingSpeechNum == 0)
                {
                    txtMainPanel.text = ("Welcome to Polyville!");
                }

                if (KingSpeechNum == 1)
                {
                    txtMainPanel.text = ("I am the King.");
                }

                if (KingSpeechNum == 2)
                {
                    txtMainPanel.text = ("Our land has been plagued with a poisonous fog, limiting us to living in a very small part of our world.");
                }

                if (KingSpeechNum == 3)
                {
                    txtMainPanel.text = ("The only way to lift the fog and save our kingdom is to build a large windmill.");
                }

                if (KingSpeechNum == 4)
                {
                    txtMainPanel.text = ("That will take some time to gather the supplies. In the meantime, could you help out around town?");
                }

                if (KingSpeechNum == 5)
                {
                    txtMainPanel.text = ("When you help out all the villagers, come back here and the windmill will be ready!");
                    
                }

                if(KingSpeechNum > 5 && questNum < 6)
                {

                    txtMainPanel.text = ("Good luck with your task!");
                    alertPanel.SetActive(false);
                }

                if(questNum >= 6)
                {
                    txtMainPanel.text = ("You're just in time! The windmill is built!");
                    StartCoroutine(FadeOut());
                    alertPanel.SetActive(false);
                }

                if (Input.GetKeyDown(KeyCode.Q) && questNum < 6)
                {
                    KingSpeechNum++;
                }
            }

            #endregion

            #region Adventurer
            if (col.name == "Adventurer")
            {

                if (qstSpear == true)
                {
                    txtMainPanel.text = ("I didn't feel safe without it.");
                }

                if (qstSpear == false)
                {
                    alertPanel.SetActive(true);
                    txtAlert.text = ("Press Q to continue...");

                    if (AdventurerSpeechNum == 0)
                    {
                        txtMainPanel.text = ("You! Come here!");
                    }

                    if (AdventurerSpeechNum >= 1)
                    {
                        txtMainPanel.text = ("My spear must have fell on my way home. I think I had it around the big rock on the way into town.");
                        alertPanel.SetActive(false);
                    }

                    if (Input.GetKeyDown(KeyCode.Q))
                    {
                        AdventurerSpeechNum++;
                    }

                    if (database.inventory.Count > 0)
                    {
                        for (int i = 0; i < database.inventory.Count; i++)
                        {
                            if (database.inventory[i].Name == "Spear")
                            {
                                reqItemNum = i;
                                break;
                            }
                        }

                        if (reqItemNum != 100)
                        {
                            txtMainPanel.text = ("Press G to give Spear");

                            if (Input.GetKey(KeyCode.G))
                            {
                                database.inventory.RemoveAt(reqItemNum);
                                reqItemNum = 100;
                                questNum++;
                                txtAlert.text = ("Spear removed from inventory");
                                StartCoroutine(AlertPanelShow());
                                qstSpear = true;
                                txtQuests.text = ("Quests: " + questNum + " /6");
                            }
                        }
                    }
                }

                
                mainPanel.SetActive(true);
            }

            #endregion

            #region Elder
            if (col.name == "Elder")
            {

                if (qstBranch == true)
                {
                    txtMainPanel.text = ("I can finally walk again!");

                }

                if (qstBranch == false)
                {
                    alertPanel.SetActive(true);
                    txtAlert.text = ("Press Q to continue...");

                    if (ElderSpeechNum == 0)
                    {
                        txtMainPanel.text = ("Come closer.");
                    }

                    if (ElderSpeechNum == 1)
                    {
                        txtMainPanel.text = ("My walking stick went missing a few days ago. Could you find a replacement for me?");
                    }

                    if (ElderSpeechNum >= 2)
                    {
                        txtMainPanel.text = ("The forest behind me might be a good place to look.");
                        alertPanel.SetActive(false);
                    }

                    if (Input.GetKeyDown(KeyCode.Q))
                    {
                        ElderSpeechNum++;
                    }

                    if (database.inventory.Count > 0)
                    {
                        for (int i = 0; i < database.inventory.Count; i++)
                        {
                            if (database.inventory[i].Name == "Branch")
                            {
                                reqItemNum = i;
                                break;
                            }
                        }

                        if (reqItemNum != 100)
                        {
                            txtMainPanel.text = ("Press G to give Branch");

                            if (Input.GetKey(KeyCode.G))
                            {
                                database.inventory.RemoveAt(reqItemNum);
                                reqItemNum = 100;
                                questNum++;
                                txtAlert.text = ("Branch removed from inventory");
                                StartCoroutine(AlertPanelShow());
                                qstBranch = true;
                                txtQuests.text = ("Quests: " + questNum + " /6");
                            }
                        }
                    }
                }
                mainPanel.SetActive(true);
            }

            #endregion

            #region Queen
            if (col.name == "Queen")
            {

                if (qstCrown == true)
                {
                    txtMainPanel.text = ("Thank you so much for finding my crown. I don't know what I would do without it.");

                }

                if (qstCrown == false)
                {
                    alertPanel.SetActive(true);
                    txtAlert.text = ("Press Q to continue...");

                    if (QueenSpeechNum == 0)
                    {
                        txtMainPanel.text = ("Hey! You!");
                    }

                    if (QueenSpeechNum == 1)
                    {
                        txtMainPanel.text = ("I seem to have lost my crown. Could you find it for me please?");
                    }

                    if (QueenSpeechNum >= 2)
                    {
                        txtMainPanel.text = ("I think the last time I had it is when I was sitting in the circle of rocks.");
                        alertPanel.SetActive(false);
                    }

                    if (Input.GetKeyDown(KeyCode.Q))
                    {
                        QueenSpeechNum++;
                    }

                    if (database.inventory.Count > 0)
                    {
                        for (int i = 0; i < database.inventory.Count; i++)
                        {
                            if (database.inventory[i].Name == "Crown")
                            {
                                reqItemNum = i;
                                break;
                            }
                        }

                        if (reqItemNum != 100)
                        {
                            txtMainPanel.text = ("Press G to give Crown");

                            if (Input.GetKey(KeyCode.G))
                            {
                                database.inventory.RemoveAt(reqItemNum);
                                reqItemNum = 100;
                                questNum++;
                                txtAlert.text = ("Crown removed from inventory");
                                StartCoroutine(AlertPanelShow());
                                qstCrown = true;
                                txtQuests.text = ("Quests: " + questNum + " /6");
                                queenCrown.SetActive(true);
                            }
                        }
                    }

                    
                }

                mainPanel.SetActive(true);
            }

            #endregion 

            #region Blacksmith
            if (col.name == "Blacksmith")
            {
                if (qstHammer == true)
                {
                    txtMainPanel.text = ("I owe you one.");

                }

                if (qstHammer == false)
                {
                    alertPanel.SetActive(true);
                    txtAlert.text = ("Press Q to continue...");

                    if (BlacksmithSpeechNum == 0)
                    {
                        txtMainPanel.text = ("You look like you're not from around here. Can you do me a favor?");
                    }

                    if (BlacksmithSpeechNum >= 1)
                    {
                        txtMainPanel.text = ("I lent my hammer to my buddy in town, if you find it could you bring it back to me?");
                        alertPanel.SetActive(false);
                    }

                    if (Input.GetKeyDown(KeyCode.Q))
                    {
                        BlacksmithSpeechNum++;
                    }

                    if (database.inventory.Count > 0)
                    {
                        for (int i = 0; i < database.inventory.Count; i++)
                        {
                            if (database.inventory[i].Name == "Hammer")
                            {
                                reqItemNum = i;
                                break;
                            }
                        }

                        if (reqItemNum != 100)
                        {
                            txtMainPanel.text = ("Press G to give Hammer");

                            if (Input.GetKey(KeyCode.G))
                            {
                                database.inventory.RemoveAt(reqItemNum);
                                reqItemNum = 100;
                                questNum++;
                                txtAlert.text = ("Hammer removed from inventory");
                                StartCoroutine(AlertPanelShow());
                                qstHammer = true;
                                txtQuests.text = ("Quests: " + questNum + " /6");
                                blacksmithHammer.SetActive(true);
                            }
                        }
                    }
                }

                

                mainPanel.SetActive(true);
            }

            #endregion

            #region Wizard
            if (col.name == "Wizard")
            {
                if (qstMushroom == true)
                {
                    txtMainPanel.text = ("This potion will heal a lot of people. They will thank you.");

                }

                if (qstMushroom == false)
                {
                    alertPanel.SetActive(true);
                    txtAlert.text = ("Press Q to continue...");

                    if (WizardSpeechNum == 0)
                    {
                        txtMainPanel.text = ("Psst...");
                    }

                    if (WizardSpeechNum == 1)
                    {
                        txtMainPanel.text = ("I have a quest for you. I've been working on a potion to heal people infected by the fog.");
                    }

                    if (WizardSpeechNum >= 2)
                    {
                        txtMainPanel.text = ("I only need one more mushroom. I think the King has some growing near his tower.");
                        alertPanel.SetActive(false);
                    }

                    if (Input.GetKeyDown(KeyCode.Q))
                    {
                        WizardSpeechNum++;
                    }

                    if (database.inventory.Count > 0)
                    {
                        for (int i = 0; i < database.inventory.Count; i++)
                        {
                            if (database.inventory[i].Name == "Mushroom")
                            {
                                reqItemNum = i;
                                break;
                            }
                        }

                        if (reqItemNum != 100)
                        {
                            txtMainPanel.text = ("Press G to give Mushroom");

                            if (Input.GetKey(KeyCode.G))
                            {
                                database.inventory.RemoveAt(reqItemNum);
                                reqItemNum = 100;
                                questNum++;
                                txtAlert.text = ("Mushroom removed from inventory");
                                StartCoroutine(AlertPanelShow());
                                qstMushroom = true;
                                txtQuests.text = ("Quests: " + questNum + " /6");
                            }
                        }
                    }
                }

                

                mainPanel.SetActive(true);

            }

            #endregion

            #region GenericCharacter
            if (col.name == "GenericCharacter")
            {
                if (qstPotion == true)
                {
                    txtMainPanel.text = ("I am feeling much better. I hope the fog lifts soon...");

                }

                if (qstPotion == false)
                {
                    alertPanel.SetActive(true);
                    txtAlert.text = ("Press Q to continue...");

                    if (GenericCharacterSpeechNum == 0)
                    {
                        txtMainPanel.text = ("My family used to live here. Before the fog...");
                    }

                    if (GenericCharacterSpeechNum == 1)
                    {
                        txtMainPanel.text = ("I've stayed here since, waiting for the fog to lift.");
                    }

                    if (GenericCharacterSpeechNum == 2)
                    {
                        txtMainPanel.text = ("I think it might be having an effect on me. I've not been feeling well recently.");
                    }

                    if (GenericCharacterSpeechNum >= 3)
                    {
                        txtMainPanel.text = ("Can you get me a potion for my illness? I think the Wizard has one stashed away behind his tower.");
                        alertPanel.SetActive(false);
                    }

                    if (Input.GetKeyDown(KeyCode.Q))
                    {
                        GenericCharacterSpeechNum++;
                    }

                    if (database.inventory.Count > 0)
                    {
                        for (int i = 0; i < database.inventory.Count; i++)
                        {
                            if (database.inventory[i].Name == "Potion")
                            {
                                reqItemNum = i;
                                break;
                            }
                        }

                        if (reqItemNum != 100)
                        {
                            txtMainPanel.text = ("Press G to give Potion");

                            if (Input.GetKey(KeyCode.G))
                            {
                                database.inventory.RemoveAt(reqItemNum);
                                reqItemNum = 100;
                                questNum++;
                                txtAlert.text = ("Potion removed from inventory");
                                StartCoroutine(AlertPanelShow());
                                qstPotion = true;
                                txtQuests.text = ("Quests: " + questNum + " /6");
                            }
                        }
                    }
                }

                

                mainPanel.SetActive(true);

            }

            #endregion
        }

        if (col.tag == "Item")
        {
            txtMainPanel.text = ("Press G to pick up " + col.name);
            mainPanel.SetActive(true);
            if (Input.GetKey(KeyCode.G))
            {
                Destroy(col.gameObject);
                mainPanel.SetActive(false);

                txtAlert.text = (col.name + " placed in inventory (I)");

                Items a = new Items();
                a.Name = col.name;

                //Change image here
                if (col.name == "Spear")
                {
                    a.Img = spearImage;
                }

                if (col.name == "Potion")
                {
                    a.Img = potionImage;
                }

                if (col.name == "Crown")
                {
                    a.Img = crownImage;
                }

                if (col.name == "Hammer")
                {
                    a.Img = hammerImage;
                }

                if (col.name == "Branch")
                {
                    a.Img = branchImage;
                }

                if (col.name == "Mushroom")
                {
                    a.Img = mushroomImage;
                }

                database.inventory.Add(a);
                StartCoroutine(AlertPanelShow());

            }
        }
    }

    IEnumerator AlertPanelShow()
    {
        alertPanel.SetActive(true);
        yield return new WaitForSeconds(3);
        alertPanel.SetActive(false);
    }

    void OnTriggerExit(Collider collision)
    {
        mainPanel.SetActive(false);
        alertPanel.SetActive(false);
    }

    void Fade()
    {
        fadeScreen.color = Color.Lerp(fadeScreen.color, Color.black, Time.deltaTime);

        if(fadeScreen.color.a >= .9f)
        {
            SceneManager.LoadScene("_CUTSCENE_", LoadSceneMode.Single);
        }
    }

    IEnumerator FadeOut()
    {
        yield return new WaitForSeconds(3);

        qstPanel.SetActive(false);
        mainPanel.SetActive(false);
        alertPanel.SetActive(false);

        Fade();
        
    }
}
