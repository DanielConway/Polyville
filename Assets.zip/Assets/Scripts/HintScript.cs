﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HintScript : MonoBehaviour {
    public GameObject mushroom, potion, crown, hammer, spear, branch;

    public GameObject confirmPanel;

    private string mode;
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
        
	}

    public void quitMode() {
        mode = "Quit";
        confirmPanel.SetActive(true);
    }
    public void hintsMode() {
        mode = "Hints";
        confirmPanel.SetActive(true);
    }
    public void ConfirmChecker()
    {
        if (mode == "Quit")
        {
            CloseGame();
        }

        if (mode == "Hints")
        {
            Hints();
        }

        
    }

    public void CloseGame()
    {
        Application.Quit();
    }

    public void closePanel()
    {
        confirmPanel.SetActive(false);
    }
    public void Hints()
    {
        confirmPanel.SetActive(false);
        mushroom.GetComponent<LineRenderer>().enabled = true;
        potion.GetComponent<LineRenderer>().enabled = true;
        crown.GetComponent<LineRenderer>().enabled = true;
        hammer.GetComponent<LineRenderer>().enabled = true;
        spear.GetComponent<LineRenderer>().enabled = true;
        branch.GetComponent<LineRenderer>().enabled = true;
        
    }
}
