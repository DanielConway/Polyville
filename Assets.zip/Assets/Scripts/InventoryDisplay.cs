﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class InventoryDisplay : MonoBehaviour {

    public int slotNum;
    public Image invImg;
    public Text invTxt;

    InventoryScript database;

    // Use this for initialization
    void Start () {
        database = GameObject.Find("Scripts").GetComponent<InventoryScript>();


    }
	
	// Update is called once per frame
	void Update () {

        invTxt.text = database.inventory[slotNum].Name;
        invImg.sprite = database.inventory[slotNum].Img;
    }
}
