﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class InventoryScript : MonoBehaviour {
    public GameObject invPanel;
    private bool invPanelOpen;

    public List<Items> inventory = new List<Items>();

    // Use this for initialization
    void Start () {
        invPanelOpen = false;
        
}
	
	// Update is called once per frame
	void Update () {
        //Inventory toggle
        if (Input.GetKeyDown(KeyCode.I))
        {
            if(invPanelOpen == false)
            {
                invPanel.SetActive(true);
                invPanelOpen = true;
                return;
            }

            if (invPanelOpen == true)
            {
                invPanel.SetActive(false);
                invPanelOpen = false;

                return;
            }
        }
	}
}

[System.Serializable]

public class Items
{

    public string Name;
    public Sprite Img;

}
