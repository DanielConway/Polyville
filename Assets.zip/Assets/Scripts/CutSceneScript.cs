﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class CutSceneScript : MonoBehaviour {

    public Image fadeScreenIn;
    public GameObject fadeScreenInGO;
	// Use this for initialization
	void Start () {

        StartCoroutine(FadeIn());

    }
	
	// Update is called once per frame
	void Update () {
		
	}

    public void Close()
    {
        Debug.Log("Close Game");
        Application.Quit();
    }

    IEnumerator FadeIn()
    {
        Color temp = fadeScreenIn.color;

        while (temp.a <= 1)
        {
            temp.a -= Time.deltaTime / 5f;
            fadeScreenIn.color = temp;

            if (fadeScreenIn.color.a <= 0.001f)
            {
                fadeScreenInGO.SetActive(false);
            }

            yield return null;
        }
        

    }
}
