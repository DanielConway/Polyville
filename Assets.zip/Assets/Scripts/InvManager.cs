﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class InvManager : MonoBehaviour {

    InventoryScript database;

    public GameObject slot1, slot2, slot3, slot4, slot5, slot6;
    // Use this for initialization
    void Start () {
        database = GameObject.Find("Scripts").GetComponent<InventoryScript>();
    }
	
	// Update is called once per frame
	void Update () {
        //Inventory checker
		if (database.inventory.Count == 1)
        {
            slot1.SetActive(true);
        }
        if (database.inventory.Count == 2)
        {
            slot2.SetActive(true);
        }
        if (database.inventory.Count == 3)
        {
            slot3.SetActive(true);
        }
        if (database.inventory.Count == 4)
        {
            slot4.SetActive(true);
        }
        if (database.inventory.Count == 5)
        {
            slot5.SetActive(true);
        }
        if (database.inventory.Count == 6)
        {
            slot6.SetActive(true);
        }

        //Inventory remover

        if (database.inventory.Count < 1)
        {
            slot1.SetActive(false);
        }
        if (database.inventory.Count < 2)
        {
            slot2.SetActive(false);
        }
        if (database.inventory.Count < 3)
        {
            slot3.SetActive(false);
        }
        if (database.inventory.Count < 4)
        {
            slot4.SetActive(false);
        }
        if (database.inventory.Count < 5)
        {
            slot5.SetActive(false);
        }
        if (database.inventory.Count < 6)
        {
            slot6.SetActive(false);
        }
    }
}
